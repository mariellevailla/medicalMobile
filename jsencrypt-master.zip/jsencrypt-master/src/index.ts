import JSEncrypt from "./JSEncrypt";
(window as any).JSEncrypt = JSEncrypt;
export { JSEncrypt };
export default JSEncrypt;
