export declare function hex2b64(h: string): string;
export declare function b64tohex(s: string): string;
export declare function b64toBA(s: string): number[];
