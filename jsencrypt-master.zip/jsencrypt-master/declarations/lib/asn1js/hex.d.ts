export declare const Hex: {
    decode(a: string): number[];
};
